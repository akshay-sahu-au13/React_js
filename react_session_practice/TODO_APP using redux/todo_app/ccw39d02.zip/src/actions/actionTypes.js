
export default {
    list: "TODO/LIST",
    add:"ADD_ITEM",
    delete:"DELETE_ITEM",
    edit:"EDIT_ITEM",
    done:"COMPLETED_ITEM"
}