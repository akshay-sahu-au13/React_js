const webPaths = {
    HOME: "/",
    PROFILE: "/profile",
    
}

export default webPaths;